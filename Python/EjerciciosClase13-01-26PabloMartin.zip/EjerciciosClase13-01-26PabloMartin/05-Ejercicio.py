n1 = float(input("Ingresa la nota 1: "))
n2 = float(input("Ingresa la nota 2: "))
n3 = float(input("Ingresa la nota 3: "))

promedio = (n1 + n2 + n3) / 3

print(f"El promedio de las notas es: {promedio}")