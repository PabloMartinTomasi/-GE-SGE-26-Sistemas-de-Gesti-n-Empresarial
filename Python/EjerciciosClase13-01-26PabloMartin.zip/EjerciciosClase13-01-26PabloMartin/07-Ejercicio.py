kmRecoridos = float(input("Ingresa los kilómetros recorridos: "))
litrosConsumidos = float(input("Ingresa los litros consumidos: "))

consumoMedio = litrosConsumidos / kmRecoridos

print(f"El consumo medio es: {consumoMedio} litros/km")