a = float(input("Ingresa el valor de a: "))
b = float(input("Ingresa el valor de b: "))

raizCuadrada = (a ** 2 + b ** 2) ** 0.5
print(f"La raíz es: {raizCuadrada}")