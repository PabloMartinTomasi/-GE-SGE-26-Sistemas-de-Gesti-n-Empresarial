a = int(input("Ingresa el valor de a: "))
b = int(input("Ingresa el valor de b: "))
c = int(input("Ingresa el valor de c: "))

y = (a + b + c) / (a * b)
print(f"El valor de y es: {y}")